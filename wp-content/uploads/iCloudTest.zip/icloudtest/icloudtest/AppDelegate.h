//
//  AppDelegate.h
//  icloudtest
//
//  Created by alex on 11-11-3.
//  Copyright (c) 2011年 北京. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
