/** Automatically generated file. DO NOT MODIFY */
package com.ies.brewclock;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}