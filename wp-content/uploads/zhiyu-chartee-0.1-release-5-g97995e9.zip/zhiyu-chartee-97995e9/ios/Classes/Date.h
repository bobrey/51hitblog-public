//
//  CustomDate.h
//  tzz
//
//  Created by zzy on 10/17/11.
//  Copyright 2011 Zhengzhiyu. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSDate (Helpers) 

@end
