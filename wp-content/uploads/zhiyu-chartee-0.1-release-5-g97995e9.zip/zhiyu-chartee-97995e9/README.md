### What is Chartee

Chartee is a charting library which currently supports ios platform.

### How to use

Just download the source code, then build and run the project with XCode.

screenshot:
![](https://github.com/zhiyu/chartee/raw/master/resource/demo.png)