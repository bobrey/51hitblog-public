package com.example.TestHandler;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: P13017
 * Date: 13/10/30
 * Time: 17:15
 * To change this template use File | Settings | File Templates.
 */
public class DownloadImage implements  Runnable{

    private  Handler handler;

    public DownloadImage(Handler handler) {
        this.handler = handler;
    }

    @Override
    public void run() {
        Message msg       = handler.obtainMessage();
        Bundle bundle      = new Bundle();

        SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss MM/dd/yyyy");
        String dateString           = dateFormat.format(new Date());

        bundle.putString("myKey",dateString);
        msg.setData(bundle);
        handler.sendMessage(msg);
    }
}
