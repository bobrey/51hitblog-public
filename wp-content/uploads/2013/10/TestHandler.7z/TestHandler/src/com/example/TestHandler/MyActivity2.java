package com.example.TestHandler;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;

public class MyActivity2 extends Activity {
        Handler handler = new Handler()  {

        @Override
        public void handleMessage(Message msg) {
//            TextView myTextView = (TextView)findViewById(R.id.myTextView);
//            myTextView.setText("Button Presed");

            Bundle bundle       = msg.getData();
            String string       = bundle.getString("myKey");

            TextView myTextView = (TextView)findViewById(R.id.myTextView);
            myTextView.setText(string);
        }
    } ;


    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }

    /**
     *  click the button
     * @param view
     */
      public void btnClick(View view){
          Runnable runnable = new Runnable() {
              @Override
              public void run() {
//                  long endTime = System.currentTimeMillis() + 20 * 1000;
//                  while (System.currentTimeMillis() < endTime){
//                      synchronized (this){
//                          try {
//                              wait(endTime - System.currentTimeMillis());
//                          } catch (InterruptedException e) {
//                              e.printStackTrace();
//                          }
//                      }
//                  }
//                  handler.sendEmptyMessage(0);

                  Message msg       = handler.obtainMessage();
                  Bundle bundle      = new Bundle();

                  SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss MM/dd/yyyy");
                  String dateString           = dateFormat.format(new Date());

                  bundle.putString("myKey",dateString);
                  msg.setData(bundle);
                  handler.sendMessage(msg);
              } //end run
          };

          Thread myThread = new Thread(runnable);
          myThread.start();
      } //end click

}





