package com.example.TestHandler;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.TextView;
import android.view.View;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.LogRecord;

public class MyActivity extends Activity implements Handler.Callback{

    Handler handler = new Handler(this);

//        Handler handler = new Handler()  {
//        @Override
//        public void handleMessage(Message msg) {
//            Bundle bundle       = msg.getData();
//            String string       = bundle.getString("myKey");
//
//            TextView myTextView = (TextView)findViewById(R.id.myTextView);
//            myTextView.setText(string);
//        }
//    } ;


    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }

    /**
     *  click the button
     * @param view
     */
      public void btnClick(View view){
          DownloadImage di = new DownloadImage(handler);
          Thread myThread = new Thread(di);
          myThread.start();
      } //end click


    @Override
    public boolean handleMessage(Message msg) {
        Bundle bundle       = msg.getData();
        String string       = bundle.getString("myKey");

        TextView myTextView = (TextView)findViewById(R.id.myTextView);
        myTextView.setText(string);
        return false;
    }
}





