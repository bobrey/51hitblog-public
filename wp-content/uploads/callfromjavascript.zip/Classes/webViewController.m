//
//  webViewController.m
//  web
//
//  Created by ＡＰＰＬＥ蔡小勋 on 09-7-9.
//  Copyright 太阳城 2009. All rights reserved.
//

#import "webViewController.h"

@implementation webViewController
@synthesize WebView;

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	[WebView setOpaque:NO];
	[WebView setBackgroundColor:[UIColor clearColor]];
	[self BtnAction];
}

-(IBAction)BtnAction{
	NSString *resourcePath = [ [NSBundle mainBundle] resourcePath];
	NSString *filePath = [resourcePath stringByAppendingPathComponent:@"0.html"];
	NSString *htmlstring=[[NSString alloc] initWithContentsOfFile:filePath  encoding:NSUTF8StringEncoding error:nil];   
	[WebView loadHTMLString:htmlstring  baseURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] bundlePath]]];	
	Nav.topItem.title=@"Welcome";
	Nav.topItem.leftBarButtonItem=nil;
}

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];	
	// Release any cached data, images, etc that aren't in use.
}
- (BOOL)webView:(UIWebView*)webView shouldStartLoadWithRequest:(NSURLRequest*)request navigationType:(UIWebViewNavigationType)navigationType {
		NSString *requestString = [[request URL] absoluteString];
		NSArray *components = [requestString componentsSeparatedByString:@":"];
		if ([components count] > 1 && [(NSString *)[components objectAtIndex:0] isEqualToString:@"testapp"]) {
			if([(NSString *)[components objectAtIndex:1] isEqualToString:@"alert"]) 
			{
				UIAlertView *alert = [[UIAlertView alloc] 
																	initWithTitle:@"Alert from Cocoa Touch" message:[components objectAtIndex:2]
																	delegate:self cancelButtonTitle:nil
																	otherButtonTitles:@"OK", nil];
				[alert show];
			}
			return NO;
		}
	return YES;
}

- (void)dealloc {
    [super dealloc];
}

@end
