﻿var EventDispatcher = {
    addEventListener:function(eventType, handler){
        if(!this.eventMap){
            this.eventMap = {};
        }

        //every event can add several listing
        if(!this.eventMap[eventType]){
            this.eventMap[eventType] = [];
        }

        //push the callback event into handle array
        this.eventMap[eventType].push(handler);
    },

    removeEventListener:function (eventType, handler){
        for(var i=0; i<this.eventMap[eventType].length; i++){
            if(this.eventMap[eventType][i] == handler){
                this.eventMap[eventType].splice(i,1);
                break;
            }
        }
    },

    dispatchEvent:function(event){
        var eventType = event.type;
        for(var i=0; i<this.eventMap[eventType].length; i++){
            this.eventMap[eventType][i](event);
        }
    }
};


Object.prototype.extend = function(base){
    for (var key in base){
        if(base.hasOwnProperty(key)){
            this[key] = base[key];
        }
    }
    return this;
};