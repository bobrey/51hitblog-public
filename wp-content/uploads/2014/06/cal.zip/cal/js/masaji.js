﻿
function DataGrid(element,  interval){
    this.columns = [];
    this.rows = [];

    element.innerHTML = '<table class="table table-bordered table-striped"><thead><tr></tr></thead><tbody></tbody><table>';

    this.header  = element.firstChild.tHead;
    this.tbody   = element.firstChild.tBodies[0];

    this.config  =  {
        five_minute :  6,
        ten_minute :  11,
        fifteen_minute: 11,
        thirteen_minute: 24
    };

    this.interval = interval;
    this.selectedRow = null;
}


DataGrid.prototype = {

    loadColumns: function(columns){

        if(this.header.rows.length > 0){
            this.header.removeChild(this.header.rows[0]);
        }
        var tr = this.header.insertRow(0);
        tr.style.background = "#000000";

        var th = tr.insertCell(0); //left corner
        th.innerHTML = "11";
        th.id = "left-corner";

        var hours = this.config[this.interval];
        for(var i=1; i<=hours; i++){
            var th = tr.insertCell(i);
            th.innerHTML =  new Date().getHours()  +  (i-2);    // columns[i].label;
            if(hours ==6){
                th.colSpan = 12;
            }
        }
        this.columns = columns;
    },

    loadData:function(data){
        for(var i=0; i<data.length; i++){
            this.insertRow(data[i]);
        }
        //send load event
        var event = {
            type:"loadCompleted",
            target:this
        };
        this.dispatchEvent(event);
    },

    insertRow:function(data){
        var row = new DataRow(data,this);
        this.tbody.appendChild(row.dom);

        this.rows.push(row);

        var that = this;
        row.addEventListener("selected", function(event){
            that.select(event.row);
        });

        //send event add new row
        var event = {
            type: "rowInserted",
            newRow:row,
            target:this
        };
        this.dispatchEvent(event);
    },

    removeRow:function(row){
        if( row == this.selectedRow){
            this.selectedRow = null;
        }

        this.tbody.removeChild(row.dom);
        row.destroy();

        for(var i=0; i<this.rows.length; i++){
            if(row == this.rows[i]){
                this.rows.splice(i,1);
                break;
            }
        }

        //send event remove
        var event = {
            type: "rowRemoved",
            target:this
        };
        this.dispatchEvent(event);
    },

    select:function(row){
        var event = {
            type: "changed",
            target:this,
            oldRow: this.selectedRow,
            newRow:row
        };

        if(this.selectedRow){
            this.selectedRow.select(false);
        }

        if(row){
            row.select(true);
        }

        this.selectedRow = row;

        this.dispatchEvent(event);
    }
}.extend(EventDispatcher);


function DataRow(data, grid){
    this.data = data;
    this.grid = grid;

    this.create();
}

DataRow.prototype = {
    create:function(){
        var row = document.createElement("tr");
        for(var i = 0; i<this.grid.columns.length; i++){
            var cell = document.createElement("td");
            cell.innerHTML = this.data[this.grid.columns[i].field] || "";
            row.appendChild(cell);
        }
        this.dom = row;

        var that = this;
        row.onclick = function(event){
            var newEvent = {
                type: "selected",
                target:that,
                row:that
            };
            that.dispatchEvent(newEvent); //007
        }
    },

    destroy:function(){
        this.dom    = null;
        this.data   = null;
        this.grid   = null;
    },

    select:function (flag){
        if(flag){
            this.dom.className = "info";
        }else{
            this.dom.className = "";
        }
    },

    set:function(key,value){
        this.data[key] = value;

        for(var i=0; i< this.grid.columns.length; i++){
            if(key == this.grid.columns[i].field){
                this.dom.childNodes[i].innerHTML = value;
                break;
            }
        }
    },

    get:function(key){
        return this.data[key];
    },

    refresh:function(data){
        this.data = data;

        for(var i=0; i<this.grid.columns.length; i++){
            this.dom.childNodes[i].innerHTML = data[this.grid.columns[i].field] || "";
        }
    }
}.extend(EventDispatcher);






