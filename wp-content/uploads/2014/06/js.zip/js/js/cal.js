$(function() {
    var drage = $( ".draggable" );
    drage.draggable();
});

$( ".selectable" ).selectable();


$('#btn_tr_ap').click(function(){
    var pin = $('#tr_ap');
    pin.before('<tr height="18" style="height:13.5pt;" class="selectable">  ' +
                    '<td height="18"  style="height:13.5pt;"> <div class="alert-info">スタッフ CC</div></td> ' +
                    ' <td>　</td>' +
                     '<td>　</td>' +
                    ' <td>　</td>' +
                    '<td>　</td>' +
                    '<td>　</td>' +

                    ' <td>　</td>' +
                    '<td>　</td>' +
                    ' <td>　</td>' +
                    '<td>　</td>' +
                    '<td>　</td>' +

                    ' <td>　</td>' +
                    '<td>　</td>' +
                    ' <td>　</td>' +
                    '<td>　</td>' +
                    '<td>　</td>' +


                    ' <td>　</td>' +
                    '<td>　</td>' +
                    ' <td>　</td>' +
                    '<td>　</td>' +
                    '<td>　</td>' +


                    ' <td>　</td>' +
                    '<td>　</td>' +
                    ' <td>　</td>' +
                    '<td>　</td>' +
                    '<td>　</td>' +

                    ' <td>　</td>' +
                    '<td>　</td>' +
                    ' <td>　</td>' +
                    '<td>　</td>' +
                    '<td>　</td>' +

                    ' <td>　</td>' +
                    '<td>　</td>' +
                    ' <td>　</td>' +
                    '<td>　</td>' +
                    '<td>　</td> </tr>'
    );

    $( ".selectable" ).selectable();

});