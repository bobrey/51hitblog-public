#include <openssl/evp.h>
#include <openssl/bio.h>
#include <openssl/buffer.h>

int main(int argc, char **argv)
{
char out[1024];

memset(out,0,1024);

if (argc==3) {

 if (strncmp(argv[1],"enc", 3)==0) {
   base64_encode(out, argv[2], strlen(argv[2]));
   printf("Enc %s = %s\n",argv[2], out);
 }

 if  (strncmp(argv[1],"dec", 3)==0) {
   int n = base64_decode(argv[2], out);
   printf("Dec %s (%d) = %s\n",argv[2], n, out);
 }
}
}

int base64_encode(char *out, const char *in, int len)
{
  BIO *bmem, *b64;
  BUF_MEM *bptr;

  b64 = BIO_new(BIO_f_base64());
  bmem = BIO_new(BIO_s_mem());
  b64 = BIO_push(b64, bmem);
  BIO_write(b64, in, len);
  BIO_flush(b64);
  BIO_get_mem_ptr(b64, &bptr);
  memcpy(out, bptr->data, bptr->length-1);
  out[bptr->length-1] = 0;

  BIO_free_all(b64);

  return bptr->length-1;
}

int base64_decode(char *in, char *out)
{
  BIO *b64, *bmem;
  int length = strlen(in);
  int read;

  b64 = BIO_new(BIO_f_base64());
  bmem = BIO_new_mem_buf(in, length);
  bmem = BIO_push(b64, bmem);
  read = BIO_read(bmem, out, length);
  BIO_free_all(bmem);
  return read;
}
