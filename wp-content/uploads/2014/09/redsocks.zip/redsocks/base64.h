void base64(char *out, const char *in, int len);
