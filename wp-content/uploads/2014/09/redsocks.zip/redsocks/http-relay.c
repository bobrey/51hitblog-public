/* redsocks - transparent TCP-to-proxy redirector
 * Copyright (C) 2007-2008 Leonid Evdokimov <leon@darkk.net.ru>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/** http-relay upstream module for redsocks
 */

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include "log.h"
#include "redsocks.h"
#include "http-ntlm.h"

#define HTTP_HEAD_WM_HIGH 4096  // that should be enough for one HTTP line.

typedef enum httpr_state_t {
	httpr_new,
        httpr_request_sent,
        httpr_reply_came,
} httpr_state;


static char *authheader = NULL;
static char **headers=NULL;
static struct evbuffer *buff=NULL;

#define HSIZE 64

static void init_headers() {
 if (headers == NULL) {
	headers = malloc(HSIZE*sizeof(void *));
	bzero(headers, HSIZE*sizeof(void *));
 }
}

static void add_header(char *header) {
 int i;

 if (header==NULL)
	return;

 for (i=0; headers[i]; i++);
 headers[i]=strdup(header);
}

static void free_headers() {
 int i;

 for (i=0; headers[i]; i++) free(headers[i]);
 bzero(headers, HSIZE*sizeof(void *));
}

static int has_header(char *header) {
int i, found=0;

 for (i=0; headers[i]; i++) {
  if (strncasecmp(headers[i],header,strlen(header))==0) {
	found=i;
	break;
  }
 }
 return found;
}

static int get_content_length() {
int i=has_header("Content-length");
int n=0;

if (i)
 n=atol(headers[i]+16);
return n;
}

static void fixup_headers() {
int i, found=0;

 for (i=0; headers[i]; i++) {
  if (strncmp(headers[i],"Host",4)==0) {
	found=i;
	break;
  }
 }

 if (found) {
	char *p, *host, *header0;

//fprintf(stderr, "ORIGINAL %s\n", headers[0]);
	host=headers[found]+6;
	p = strchr(headers[0],' ');

	if (p==NULL || *(p+1) != '/') return;

	header0=malloc(strlen(headers[0]) + strlen(host) + 10);	
	strncpy(header0, headers[0], p-headers[0]+1);
	sprintf(header0 + (p-headers[0]+1),"http://%s%s",host, p+1);
//fprintf(stderr, "FIXUP %s\n", header0);
	free(headers[0]);
	headers[0]=header0;
 }
}

/*
 * Translate a sockaddr_in structure into a usable ASCII hostname.
 */
static void lookup_hostname(struct sockaddr_in *addr, char *hostname, int hostlen)
{
	struct hostent	*host;

	if ((host = gethostbyaddr((char *)&addr->sin_addr, sizeof(addr->sin_addr), AF_INET)) != NULL)
	{
		strncpy(hostname, host->h_name, hostlen);
		hostname[hostlen - 1] = '\0';
	} else {
		strncpy(hostname, inet_ntoa(addr->sin_addr), hostlen);
		hostname[hostlen - 1] = '\0';
	}
}

static void httpr_client_init(redsocks_client *client)
{
#if 0
	if (client->instance->config.login)
		redsocks_log_error(client, LOG_WARNING, "login is ignored for http-relay connections");

	if (client->instance->config.password)
		redsocks_log_error(client, LOG_WARNING, "password is ignored for http-relay connections");
#endif
	if (authheader == NULL && client->instance->config.login && client->instance->config.password) {
		char *basicauth = malloc (2 + strlen(client->instance->config.login)+strlen(client->instance->config.password));

		authheader=malloc(128);
		strcpy(authheader, "Proxy-Authorization: Basic ");
		sprintf(basicauth,"%s:%s",client->instance->config.login,client->instance->config.password);
		base64_encode(basicauth, strlen(basicauth), authheader+27);
		free (basicauth);
	}
	client->state = httpr_new;
	buff=NULL;
}

static void httpr_client_fini(redsocks_client *client)
{
	if (buff) {
		evbuffer_free(buff);
		buff = 0;
	}
}

static void httpr_relay_write_cb(struct bufferevent *buffev, void *_arg)
{
	redsocks_client *client = _arg;
	int len;

	assert(buff);

	redsocks_touch_client(client);

	len = bufferevent_write_buffer(client->relay, buff);
	// free is done either at _start_relay or at _drop_client

	if (len >= 0) {
		redsocks_start_relay(client);
	}
	else {
		redsocks_log_errno(client, LOG_ERR, "bufferevent_write_buffer");
		redsocks_drop_client(client);
	}

}

// drops client on failure
static int httpr_append_header(redsocks_client *client, char *line)
{
	int error;

	error = evbuffer_add(buff, line, strlen(line));
	if (!error)
		evbuffer_add(buff, "\x0d\x0a", 2);
	if (error) {
		redsocks_log_errno(client, LOG_ERR, "evbuffer_add");
	}
	return error;
}



static void httpr_client_read_cb(struct bufferevent *buffev, void *_arg)
{
	redsocks_client *client = _arg;
	char *line = NULL;
	int connect_relay = 0;
	int i;
	
	redsocks_touch_client(client);

	init_headers();

	while ( !connect_relay && (line = evbuffer_readline(buffev->input))) {
			if (strlen(line)==0) {
				add_header(authheader);
				add_header("Proxy-Connection: close");
				add_header("Connection: close");
				add_header("");

				fixup_headers();
				for (i=0; headers[i]; i++)
					httpr_append_header(client, headers[i]);

//				if (has_header("Content-length")) {
//					fprintf(stderr,"GOT LEN=%d\n",get_content_length());
//					char *p=malloc(get_content_length());
//					bufferevent_read(buffev, p, get_content_length());
//					evbuffer_add(httpr->buff,p, get_content_length());
//					free(p);
//				}

				free_headers();

				connect_relay=1;

			} else {
				if (strncasecmp(line,"Proxy-Connection",16) !=0 &&
				    strncasecmp(line,"Connection", 10) != 0)
				add_header(line);
			}
		free(line);

	}

	if (connect_relay)
		redsocks_connect_relay(client);
}

static void httpr_relay_read_cb(struct bufferevent *buffev, void *_arg)
{
	redsocks_client *client = _arg;
	int dropped = 0;

//	assert(client->state >= httpr_request_sent);

	redsocks_touch_client(client);
fprintf(stderr, "*** in httpr_read_cb %d, %d\n", client->state, httpr_request_sent);
	if (client->state == httpr_request_sent) {
		size_t len = EVBUFFER_LENGTH(buffev->input);
		char *line = evbuffer_readline(buffev->input);
		if (line) {
fprintf(stderr, "************* %s\n", line);
			unsigned int code;
			if (sscanf(line, "HTTP/%*u.%*u %u", &code) == 1) { // 1 == one _assigned_ match
				if (200 <= code && code <= 299) {
					client->state = httpr_reply_came;
				}
				else {
					redsocks_log_error(client, LOG_NOTICE, "%s", line);
					redsocks_drop_client(client);
					dropped = 1;
				}
			}
			free(line);
		}
	}

	if (dropped)
		return;

	while (client->state == httpr_reply_came) {
		char *line = evbuffer_readline(buffev->input);
		if (line) {
			if (strlen(line) == 0) {
//				client->state = httpr_headers_skipped;
			}
			free(line);
		}
		else {
			break;
		}
	}

//redsocks_start_relay(client);
}

static void httpr_connect_relay(redsocks_client *client)
{
        int error;

        buff = evbuffer_new();
        if (!buff) {
                redsocks_log_errno(client, LOG_ERR, "evbuffer_new");
                redsocks_drop_client(client);
	}

        client->client->readcb = httpr_client_read_cb;
        error = bufferevent_enable(client->client, EV_READ);
        if (error) {
                redsocks_log_errno(client, LOG_ERR, "bufferevent_enable");
                redsocks_drop_client(client);
	}
}

relay_subsys http_relay_subsys =
{
	.name          = "http-relay",
	.payload_len   = sizeof(void *),
	.readcb        = httpr_relay_read_cb,
	.writecb       = httpr_relay_write_cb,
	.init          = httpr_client_init,
        .connect_relay = httpr_connect_relay,
};

/* vim:set tabstop=4 softtabstop=4 shiftwidth=4: */
/* vim:set foldmethod=marker foldlevel=32 foldmarker={,}: */
