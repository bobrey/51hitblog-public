//
//  webViewController.h
//  web
//
//  Created by Lixf on 09-7-28.
//  Copyright 太阳城 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface webViewController : UIViewController {
	IBOutlet UIWebView *WebView;
	IBOutlet UINavigationBar *Nav;
	IBOutlet UIBarButtonItem *BackBtn;
}
@property (nonatomic, retain) IBOutlet UIWebView *WebView;
-(IBAction)BtnAction;
@end

