//
//  webViewController.m
//  web
//
//  Created by Lixf on 09-7-28.
//  Copyright 太阳城 2009. All rights reserved.
//

#import "webViewController.h"

@implementation webViewController
@synthesize WebView;

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	[WebView setOpaque:NO];
	[WebView setBackgroundColor:[UIColor clearColor]];
	Nav.topItem.title=@"Welcome";
	Nav.topItem.leftBarButtonItem=nil;	
	
	NSString *HTMLData = @"Hello this is a test Hello this is a test Hello this is a test Hello this is a test Hello this is a test<p><img src=\"005-1.jpg\" alt=\"picture\"/>";
	[WebView loadHTMLString:HTMLData baseURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] bundlePath]]];
}


// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];	
	// Release any cached data, images, etc that aren't in use.
}

/*
- (BOOL)webView:(UIWebView*)webView shouldStartLoadWithRequest:(NSURLRequest*)request navigationType:(UIWebViewNavigationType)navigationType {
	if (navigationType == UIWebViewNavigationTypeLinkClicked) {
		Nav.topItem.title=@"More information";
		Nav.topItem.leftBarButtonItem=BackBtn;
	}	
	return YES;
}
*/
- (void)dealloc {
    [super dealloc];
}

@end
