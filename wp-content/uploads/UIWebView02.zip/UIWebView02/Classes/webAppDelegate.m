//
//  webAppDelegate.m
//  web
//
//  Created by Lixf on 09-7-28.
//  Copyright 太阳城 2009. All rights reserved.
//

#import "webAppDelegate.h"
#import "webViewController.h"

@implementation webAppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
