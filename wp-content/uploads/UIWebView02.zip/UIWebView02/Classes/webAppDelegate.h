//
//  webAppDelegate.h
//  web
//
//  Created by Lixf on 09-7-28.
//  Copyright 太阳城 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class webViewController;

@interface webAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    webViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet webViewController *viewController;

@end

