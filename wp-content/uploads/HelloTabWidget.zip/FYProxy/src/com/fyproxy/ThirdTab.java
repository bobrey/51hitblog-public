package com.fyproxy;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class ThirdTab extends Activity{
	public void onCreate(Bundle saveInstanceBundle){
		super.onCreate(saveInstanceBundle);
		
		//third tab content
		TextView textView = new TextView(this);
		textView.setText("third tab");
		setContentView(textView);
	}

}
