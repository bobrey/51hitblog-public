package com.fyproxy;

import android.R.anim;
import android.app.Activity;
import android.app.TabActivity;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

public class tabbar extends TabActivity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        Resources res		= getResources();
        TabHost tabHost     = getTabHost();			//The activity TabHost
        TabHost.TabSpec spec;						//Resusable TabSpec for each tab
        Intent  intent;								//Reusable Intent for each tab
        
      //Create an intent to launch an Activity for the tab (to be reused)
        intent = new Intent().setClass(this, FirstTab.class);
        
        //Initialize a TabSpec for each tab and add it to the TabHost
        spec = tabHost.newTabSpec("artists").setIndicator("CN",
        		res.getDrawable(R.drawable.ic_tab_artists))
        		.setContent(intent);
        tabHost.addTab(spec);
        
        
        //Do the same for the other tabs
        intent = new Intent().setClass(this, SecondTab.class);
        spec = tabHost.newTabSpec("albums").setIndicator("JP",
        		res.getDrawable(R.drawable.ic_tab_albums)).setContent(intent);
        tabHost.addTab(spec);
        
        intent = new Intent().setClass(this, ThirdTab.class);
        spec   = tabHost.newTabSpec("songs").setIndicator("Songs",
        		res.getDrawable(R.drawable.ic_tab_songs)).setContent(intent);
        tabHost.addTab(spec);
        
        tabHost.setCurrentTab(2); 
        
       
    }
}