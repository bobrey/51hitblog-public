package com.fyproxy;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class SecondTab extends Activity {
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		
		//second tab content
		TextView textView = new TextView(this);
		textView.setText("second tab");
		setContentView(textView);
	}

}
