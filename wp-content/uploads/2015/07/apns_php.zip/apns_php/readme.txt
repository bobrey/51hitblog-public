

1.
	createDb
		apns.php {43}; apns.sql
		'localhost', 'apnsuser', 'apnspassword', 'apnsdb'

2.
	cron

3.	
	
	class_APNS.php 
		[production | sandbox]			{40}
		log path 						{80}
		product pem path 				{97}
			pass						{104}
		sandbox pem path 				{128}
			pass						{136}
			
4.
	



