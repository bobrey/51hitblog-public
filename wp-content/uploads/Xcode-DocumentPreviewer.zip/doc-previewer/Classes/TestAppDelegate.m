//
//  TestAppDelegate.m
//
//  Copyright iOSDeveloperTips.com All rights reserved.
//

#import "TestAppDelegate.h"
#import "TestViewController.h"

@implementation TestAppDelegate

@synthesize window, vc;

- (void)applicationDidFinishLaunching:(UIApplication *)application 
{   
  // Create and initialize the window
	window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];

	// Create test view controller
	vc = [[TestViewController alloc] init];

	// Create navigation controller  
	nav = [[UINavigationController alloc] initWithRootViewController:vc];
  
	[window addSubview:[nav view]];  
  [window makeKeyAndVisible];
}

- (void)dealloc 
{
	[vc release];
  [nav release];  
  [window release];
  
  [super dealloc];
}

@end
