//
//  TestAppDelegate.h
//
//  Copyright iOSDeveloperTips.com All rights reserved.
//

@class TestViewController;

@interface TestAppDelegate : NSObject <UIApplicationDelegate, UIImagePickerControllerDelegate>
{
  UIWindow 								*window;
  UINavigationController 	*nav;
  TestViewController 			*vc;
}

@property (nonatomic, retain) UIWindow *window;
@property (nonatomic, retain) TestViewController *vc;

@end

