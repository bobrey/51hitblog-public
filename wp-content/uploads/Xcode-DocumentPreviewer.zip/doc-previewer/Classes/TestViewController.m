//
//  TestViewController.m
//
//  Copyright iOSDeveloperTips.com All rights reserved.
//

#import "TestViewController.h"

@implementation TestViewController

#pragma mark -
#pragma mark Initialization

/*---------------------------------------------------------------------------
*  
*--------------------------------------------------------------------------*/
-(id)init
{
  if (self = [super init])
  {
		arrayOfDocuments = [[NSArray alloc] initWithObjects: 
			@"iOSDevTips.png", @"Remodel.xls", @"Core J2ME Technology.pdf", nil];

  }
  return self;
}

/*---------------------------------------------------------------------------
*  
*--------------------------------------------------------------------------*/
- (void)loadView 
{
	[super loadView];

	[self setTitle:@"Files Available for Preview"];
}

#pragma mark -
#pragma mark Table Management

// Customize the number of sections in the table view.
/*---------------------------------------------------------------------------
*  
*--------------------------------------------------------------------------*/
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView 
{
	return 1;
}

/*---------------------------------------------------------------------------
*  
*--------------------------------------------------------------------------*/
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	return [arrayOfDocuments count];
}

/*---------------------------------------------------------------------------
*  
*--------------------------------------------------------------------------*/
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
  static NSString *CellIdentifier = @"tableRow";
  
  UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
  if (cell == nil)
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    
	// ???
	[[cell textLabel] setText:[arrayOfDocuments objectAtIndex:indexPath.row]];
	[cell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];

	return cell;
}

/*---------------------------------------------------------------------------
*  
*--------------------------------------------------------------------------*/
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{  
	// When user taps a row, create the preview controller
	QLPreviewController *previewer = [[[QLPreviewController alloc] init] autorelease];

	// Set data source
	[previewer setDataSource:self];
  
  // Which item to preview
	[previewer setCurrentPreviewItemIndex:indexPath.row];

	// Push new viewcontroller, previewing the document
	[[self navigationController] pushViewController:previewer animated:YES];
}

#pragma mark -
#pragma mark Preview Controller

/*---------------------------------------------------------------------------
*  
*--------------------------------------------------------------------------*/
- (NSInteger) numberOfPreviewItemsInPreviewController: (QLPreviewController *) controller 
{
	return [arrayOfDocuments count];
}

/*---------------------------------------------------------------------------
*  
*--------------------------------------------------------------------------*/
- (id <QLPreviewItem>)previewController: (QLPreviewController *)controller previewItemAtIndex:(NSInteger)index 
{
	// Break the path into it's components (filename and extension)
	NSArray *fileComponents = [[arrayOfDocuments objectAtIndex: index] componentsSeparatedByString:@"."];

	// Use the filename (index 0) and the extension (index 1) to get path
  NSString *path = [[NSBundle mainBundle] pathForResource:[fileComponents objectAtIndex:0] ofType:[fileComponents objectAtIndex:1]];
                             
	return [NSURL fileURLWithPath:path];
}

#pragma mark -
#pragma mark Cleanup

/*---------------------------------------------------------------------------
*  
*--------------------------------------------------------------------------*/
- (void)dealloc 
{
	// Free up all the documents
	[arrayOfDocuments release];

	[super dealloc];
}

@end
