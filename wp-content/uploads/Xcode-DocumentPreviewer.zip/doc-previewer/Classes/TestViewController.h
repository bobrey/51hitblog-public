//
//  TestViewController.h
//
//  Copyright iOSDeveloperTips.com All rights reserved.
//

#import <QuickLook/QuickLook.h>
	
@interface TestViewController : UITableViewController <QLPreviewControllerDataSource>
{
	NSArray *arrayOfDocuments;
}

@end

